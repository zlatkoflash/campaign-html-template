<!-- List plan Template -->
<div class="table-scroller">
    <table class="table table-striped plans-table">
        <thead>
            <tr>
                <th>Title</th>
                <th>Base</th>
                <th>Code</th>
                <th>Limit</th>
                <th>Copy1</th>
                <th>Created_at</th>
                <th>&nbsp;</th>
                <th>&nbsp;</th>
                <th>&nbsp;</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>350off5 design</td>
                <td>Cupon</td>
                <td>hogehogehoge</td>
                <td>16minute</td>
                <td> 䥪ピ櫦杯楺 郎カ穞䨵ば 秺珥</td>
                <td>2013 02/03 18:45</td>
                <td><span class="plan-info"></span></td>
                <td><span class="plan-edit"></span></td>
                <td><span class="plan-delete"></span></td>
            </tr>
            <tr>
                <td>350off5 design</td>
                <td>Cupon</td>
                <td>hogehogehoge</td>
                <td>16minute</td>
                <td> 䥪ピ櫦杯楺 郎カ穞䨵ば 秺珥</td>
                <td>2013 02/03 18:45</td>
                <td><span class="plan-info"></span></td>
                <td><span class="plan-edit"></span></td>
                <td><span class="plan-delete"></span></td>
            </tr>
            <tr>
                <td>350off5 design</td>
                <td>Cupon</td>
                <td>hogehogehoge</td>
                <td>16minute</td>
                <td> 䥪ピ櫦杯楺 郎カ穞䨵ば 秺珥</td>
                <td>2013 02/03 18:45</td>
                <td><span class="plan-info"></span></td>
                <td><span class="plan-edit"></span></td>
                <td><span class="plan-delete"></span></td>
            </tr>
            <tr>
                <td>350off5 design</td>
                <td>Cupon</td>
                <td>hogehogehoge</td>
                <td>16minute</td>
                <td> 䥪ピ櫦杯楺 郎カ穞䨵ば 秺珥</td>
                <td>2013 02/03 18:45</td>
                <td><span class="plan-info"></span></td>
                <td><span class="plan-edit"></span></td>
                <td><span class="plan-delete"></span></td>
            </tr>
            <tr>
                <td>350off5 design</td>
                <td>Cupon</td>
                <td>hogehogehoge</td>
                <td>16minute</td>
                <td> 䥪ピ櫦杯楺 郎カ穞䨵ば 秺珥</td>
                <td>2013 02/03 18:45</td>
                <td><span class="plan-info"></span></td>
                <td><span class="plan-edit"></span></td>
                <td><span class="plan-delete"></span></td>
            </tr>
            <tr>
                <td>350off5 design</td>
                <td>Cupon</td>
                <td>hogehogehoge</td>
                <td>16minute</td>
                <td> 䥪ピ櫦杯楺 郎カ穞䨵ば 秺珥</td>
                <td>2013 02/03 18:45</td>
                <td><span class="plan-info"></span></td>
                <td><span class="plan-edit"></span></td>
                <td><span class="plan-delete"></span></td>
            </tr>
            <tr>
                <td>350off5 design</td>
                <td>Cupon</td>
                <td>hogehogehoge</td>
                <td>16minute</td>
                <td> 䥪ピ櫦杯楺 郎カ穞䨵ば 秺珥</td>
                <td>2013 02/03 18:45</td>
                <td><span class="plan-info"></span></td>
                <td><span class="plan-edit"></span></td>
                <td><span class="plan-delete"></span></td>
            </tr>
            <tr>
                <td>350off5 design</td>
                <td>Cupon</td>
                <td>hogehogehoge</td>
                <td>16minute</td>
                <td> 䥪ピ櫦杯楺 郎カ穞䨵ば 秺珥</td>
                <td>2013 02/03 18:45</td>
                <td><span class="plan-info"></span></td>
                <td><span class="plan-edit"></span></td>
                <td><span class="plan-delete"></span></td>
            </tr>
            <tr>
                <td>350off5 design</td>
                <td>Cupon</td>
                <td>hogehogehoge</td>
                <td>16minute</td>
                <td> 䥪ピ櫦杯楺 郎カ穞䨵ば 秺珥</td>
                <td>2013 02/03 18:45</td>
                <td><span class="plan-info"></span></td>
                <td><span class="plan-edit"></span></td>
                <td><span class="plan-delete"></span></td>
            </tr>
            <tr>
                <td>350off5 design</td>
                <td>Cupon</td>
                <td>hogehogehoge</td>
                <td>16minute</td>
                <td> 䥪ピ櫦杯楺 郎カ穞䨵ば 秺珥</td>
                <td>2013 02/03 18:45</td>
                <td><span class="plan-info"></span></td>
                <td><span class="plan-edit"></span></td>
                <td><span class="plan-delete"></span></td>
            </tr>
        </tbody>
    </table>
</div>
