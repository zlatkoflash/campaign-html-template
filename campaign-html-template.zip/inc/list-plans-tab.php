<!-- List plan Template -->
<div class="table-scroller">
    <table id="plans-table" class="table table-striped">
        <thead>
            <tr>
                <th>Plan Title</th>
                <th>UI Setting</th>
                <th>Query</th>
                <th>LatestCVR</th>
                <th>Created_at</th>
                <th>&nbsp;</th>
                <th>&nbsp;</th>
                <th>&nbsp;</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Winter Plan 5</td>
                <td>350Offplan3</td>
                <td>far from conversion</td>
                <td>6.5%</td>
                <td>2013 02/03 18:45</td>
                <td><span class="plan-info"></span></td>
                <td><span class="plan-edit"></span></td>
                <td><span class="plan-delete"></span></td>
            </tr>
            <tr>
                <td>Winter Plan 5</td>
                <td>350Offplan3</td>
                <td>far from conversion</td>
                <td>6.5%</td>
                <td>2013 02/03 18:45</td>
                <td><span class="plan-info"></span></td>
                <td><span class="plan-edit"></span></td>
                <td><span class="plan-delete"></span></td>
            </tr>
            <tr>
                <td>Winter Plan 5</td>
                <td>350Offplan3</td>
                <td>far from conversion</td>
                <td>6.5%</td>
                <td>2013 02/03 18:45</td>
                <td><span class="plan-info"></span></td>
                <td><span class="plan-edit"></span></td>
                <td><span class="plan-delete"></span></td>
            </tr>
            <tr>
                <td>Winter Plan 5</td>
                <td>350Offplan3</td>
                <td>far from conversion</td>
                <td>6.5%</td>
                <td>2013 02/03 18:45</td>
                <td><span class="plan-info"></span></td>
                <td><span class="plan-edit"></span></td>
                <td><span class="plan-delete"></span></td>
            </tr>
            <tr>
                <td>Winter Plan 5</td>
                <td>350Offplan3</td>
                <td>far from conversion</td>
                <td>6.5%</td>
                <td>2013 02/03 18:45</td>
                <td><span class="plan-info"></span></td>
                <td><span class="plan-edit"></span></td>
                <td><span class="plan-delete"></span></td>
            </tr>
        </tbody>
    </table>
</div>
